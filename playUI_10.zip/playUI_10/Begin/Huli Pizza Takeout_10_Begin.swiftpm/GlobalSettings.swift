import SwiftUI
let companyName = "Huli Pizza Takeout"
let surfgirl = "SurfGirl1"
let pizzaImg = "Pizza"
var color = Color.blue
